var footerBlocks = $('.footer-widgets > div');
var maxH = 0;

function setHeight(){
    footerBlocks.each(function(){
        if(maxH < $(this).height()){
            maxH = $(this).height();
        }
    })
    footerBlocks.css({height:maxH});
    console.log(maxH);
}

setHeight();

$(window).resize(function(){
    setHeight();
});